# -*- coding: utf-8 -*-
import hashlib
import sys
import time
import urllib.parse
import threading
import re
import io
import os
import json
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus
import requests
from requests.adapters import HTTPAdapter

# ============================================================================
# IMPLEMENTAÇÃO BENCODE MÍNIMA
# ============================================================================

class BencodeDecoder:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def decode(self):
        return self._decode_next()

    def _decode_next(self):
        if self.pos >= len(self.data):
            return None
        c = chr(self.data[self.pos])
        if c == 'i':
            return self._decode_int()
        elif c == 'l':
            return self._decode_list()
        elif c == 'd':
            return self._decode_dict()
        elif c.isdigit():
            return self._decode_string()
        else:
            raise ValueError(f"Caractere inesperado: {c}")

    def _decode_int(self):
        self.pos += 1
        end = self.data.find(b'e', self.pos)
        num = int(self.data[self.pos:end])
        self.pos = end + 1
        return num

    def _decode_string(self):
        colon = self.data.find(b':', self.pos)
        length = int(self.data[self.pos:colon])
        self.pos = colon + 1
        string = self.data[self.pos:self.pos + length]
        self.pos += length
        return string

    def _decode_list(self):
        self.pos += 1
        result = []
        while chr(self.data[self.pos]) != 'e':
            result.append(self._decode_next())
        self.pos += 1
        return result

    def _decode_dict(self):
        self.pos += 1
        result = {}
        while chr(self.data[self.pos]) != 'e':
            key = self._decode_string()
            value = self._decode_next()
            result[key] = value
        self.pos += 1
        return result

class BencodeEncoder:
    @staticmethod
    def encode(obj):
        if isinstance(obj, int):
            return f'i{obj}e'.encode()
        elif isinstance(obj, bytes):
            return f'{len(obj)}:'.encode() + obj
        elif isinstance(obj, str):
            encoded = obj.encode('utf-8')
            return f'{len(encoded)}:'.encode() + encoded
        elif isinstance(obj, list):
            result = b'l'
            for item in obj:
                result += BencodeEncoder.encode(item)
            result += b'e'
            return result
        elif isinstance(obj, dict):
            result = b'd'
            for key in sorted(obj.keys()):
                result += BencodeEncoder.encode(key)
                result += BencodeEncoder.encode(obj[key])
            result += b'e'
            return result
        else:
            raise ValueError(f"Tipo não suportado: {type(obj)}")

def bdecode(data):
    return BencodeDecoder(data).decode()

def bencode_encode(obj):
    return BencodeEncoder.encode(obj)

# ============================================================================
# CONFIGURAÇÕES
# ============================================================================

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ICON_DIR = os.path.join(ADDON_PATH, 'resources', 'media')
HANDLE = int(sys.argv[1])

results_lock = threading.Lock()

SEARCH_SOURCE = int(ADDON.getSetting('search_source'))
MAX_SEARCH_TIME = int(ADDON.getSetting('max_search_time'))
VERIFY_SSL = ADDON.getSetting('verify_ssl') == 'true'
PLAYER_MODE = int(ADDON.getSetting('player_mode'))
ALLDEBRID_APIKEY = ADDON.getSetting('alldebrid_apikey')

# AIOStreams
AIOSTREAMS_URL = ADDON.getSetting('aiostreams_url') or ''
CINEMETA_BASE_URL = "https://v3-cinemeta.strem.io"

JACKETT_HTTPS = ADDON.getSetting('jackett_https') == 'true'
JACKETT_HOST = ADDON.getSetting('jackett_host')
JACKETT_PORT = ADDON.getSetting('jackett_port')
JACKETT_APIKEY = ADDON.getSetting('jackett_apikey')
JACKETT_PROTOCOL = 'https' if JACKETT_HTTPS else 'http'
if JACKETT_PORT and JACKETT_PORT.strip():
    JACKETT_BASE_URL = f"{JACKETT_PROTOCOL}://{JACKETT_HOST}:{JACKETT_PORT}"
else:
    JACKETT_BASE_URL = f"{JACKETT_PROTOCOL}://{JACKETT_HOST}"

PROWLARR_HTTPS = ADDON.getSetting('prowlarr_https') == 'true'
PROWLARR_HOST = ADDON.getSetting('prowlarr_host')
PROWLARR_PORT = ADDON.getSetting('prowlarr_port')
PROWLARR_APIKEY = ADDON.getSetting('prowlarr_apikey')
PROWLARR_PROTOCOL = 'https' if PROWLARR_HTTPS else 'http'
if PROWLARR_PORT and PROWLARR_PORT.strip():
    PROWLARR_BASE_URL = f"{PROWLARR_PROTOCOL}://{PROWLARR_HOST}:{PROWLARR_PORT}"
else:
    PROWLARR_BASE_URL = f"{PROWLARR_PROTOCOL}://{PROWLARR_HOST}"

# IDs pré-configurados
PROWLARR_PUBLIC_TRACKERS = ADDON.getSetting('prowlarr_public_trackers')
PROWLARR_PRIVATE_TRACKERS = ADDON.getSetting('prowlarr_private_trackers')
PROWLARR_NOHR_TRACKERS = ADDON.getSetting('prowlarr_nohr_trackers')

JACKETT_SEARCH_URL = f"{JACKETT_BASE_URL}/api/v2.0/indexers/all/results"
PROWLARR_SEARCH_URL = f"{PROWLARR_BASE_URL}/api/v1/search"
PROWLARR_INDEXER_URL = f"{PROWLARR_BASE_URL}/api/v1/indexer"

ALLDEBRID_API_URL = "https://api.alldebrid.com/v4.1"

HEADERS = {
    'User-Agent': 'Kodi/Jackett2Elementum',
    'Accept': 'application/json'
}

RESOLUTION_PATTERN = re.compile(r'(2160p|1080p|720p|480p|4K|UHD)', re.IGNORECASE)
SOURCE_PATTERN = re.compile(r'(WEB-DL|WEBDL|WEBRip|BluRay|BDRip|HDRip|HDTV|AMZN|NF|DSNP|HMAX)', re.IGNORECASE)
AUDIO_PATTERN = re.compile(r'(DUAL|DUAL-AUDIO|DDP5\.1|DD5\.1|AAC|DTS|TRUEHD|Atmos)', re.IGNORECASE)
CODEC_PATTERN = re.compile(r'(H\.264|H\.265|HEVC|x264|x265|AVC)', re.IGNORECASE)

EPISODE_PATTERN = re.compile(r'S(\d+)E(\d+)', re.IGNORECASE)
QUALITY_PATTERN = re.compile(r'(2160p|4K|1080p|720p|480p)', re.IGNORECASE)
SOURCE_PATTERN_DISP = re.compile(r'(WEB-DL|WEBDL|WEBRip|BluRay|BDRip|HDTV|AMZN|NF|DSNP)', re.IGNORECASE)
AUDIO_PATTERN_DISP = re.compile(r'(TrueHD|Atmos|DDP[^ ]*|DD[^ ]*|DTS|AAC|AC-3|EAC3)', re.IGNORECASE)
CODEC_PATTERN_DISP = re.compile(r'(HEVC|H\.265|x265|H\.264|x264|AVC)', re.IGNORECASE)

def extract_video_info(filename):
    info = {'episode': '', 'quality': '', 'source': '', 'audio': '', 'codec': ''}
    ep_match = EPISODE_PATTERN.search(filename)
    if ep_match:
        info['episode'] = f"S{ep_match.group(1)}E{ep_match.group(2)}"
    q_match = QUALITY_PATTERN.search(filename)
    if q_match:
        info['quality'] = q_match.group(1).upper()
    s_match = SOURCE_PATTERN_DISP.search(filename)
    if s_match:
        info['source'] = s_match.group(1)
    a_match = AUDIO_PATTERN_DISP.search(filename)
    if a_match:
        info['audio'] = a_match.group(1)
    c_match = CODEC_PATTERN_DISP.search(filename)
    if c_match:
        info['codec'] = c_match.group(1)
    return info

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'{ADDON_ID}: {msg}', level)

def build_plugin_url(params):
    return f'plugin://{ADDON_ID}/?{urllib.parse.urlencode(params)}'

def parse_release_info(title):
    info = {'resolution': '', 'source': '', 'audio': '', 'codec': ''}
    res_match = RESOLUTION_PATTERN.search(title)
    if res_match:
        info['resolution'] = res_match.group(1)
    source_match = SOURCE_PATTERN.search(title)
    if source_match:
        info['source'] = source_match.group(1)
    audio_match = AUDIO_PATTERN.search(title)
    if audio_match:
        info['audio'] = audio_match.group(1)
    codec_match = CODEC_PATTERN.search(title)
    if codec_match:
        info['codec'] = codec_match.group(1)
    return info

def create_secure_session():
    session = requests.Session()
    if not VERIFY_SSL:
        from urllib3.exceptions import InsecureRequestWarning
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        session.verify = False
        log("AVISO: Verificação SSL desabilitada", xbmc.LOGWARNING)
    adapter = HTTPAdapter(pool_connections=10, pool_maxsize=10, max_retries=3)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session

# ============================================================================
# MENU PRINCIPAL (COM TODAS AS OPÇÕES: PROWLARR, AIOSTREAMS, ALLDEBRID)
# ============================================================================

def show_main_menu():
    # 1. Pesquisa Trackers No H&R (pré-configurados)
    list_item1 = xbmcgui.ListItem("Pesquisar Trackers No H&R (Prowlarr)")
    list_item1.setInfo('video', {'plot': 'Pesquisar nos trackers configurados como No H&R'})
    list_item1.setArt({'icon': os.path.join(ICON_DIR, 'duas.png')})
    url1 = build_plugin_url({'action': 'nohr_search_dialog'})
    xbmcplugin.addDirectoryItem(HANDLE, url1, list_item1, isFolder=False)

    # 2. Pesquisa Trackers Públicos (pré-configurados)
    list_item2 = xbmcgui.ListItem("Pesquisar Trackers Públicos (Prowlarr)")
    list_item2.setArt({'icon': os.path.join(ICON_DIR, 'publico.png')})
    list_item2.setInfo('video', {'plot': 'Pesquisar nos trackers configurados como públicos'})
    url2 = build_plugin_url({'action': 'public_search_dialog'})
    xbmcplugin.addDirectoryItem(HANDLE, url2, list_item2, isFolder=False)

    # 3. Pesquisa Trackers Privados (pré-configurados)
    list_item3 = xbmcgui.ListItem("Pesquisar Trackers Privados (Prowlarr)")
    list_item3.setArt({'icon': os.path.join(ICON_DIR, 'tres.png')})
    list_item3.setInfo('video', {'plot': 'Pesquisar nos trackers configurados como privados'})
    url3 = build_plugin_url({'action': 'private_search_dialog'})
    xbmcplugin.addDirectoryItem(HANDLE, url3, list_item3, isFolder=False)

    # 4. Pesquisa em Trackers Específicos (seleção manual)
    list_item4 = xbmcgui.ListItem("Pesquisar em Trackers Específicos (Prowlarr)")
    list_item4.setArt({'icon': os.path.join(ICON_DIR, 'pesquisa.png')})
    list_item4.setInfo('video', {'plot': 'Selecionar indexadores específicos do Prowlarr para pesquisar'})
    url4 = build_plugin_url({'action': 'tracker_search_dialog'})
    xbmcplugin.addDirectoryItem(HANDLE, url4, list_item4, isFolder=False)

    # 5. Pesquisar no AIOStreams
    list_item_aio = xbmcgui.ListItem("[COLOR FF00BFFF]Pesquisar no AIOStreams[/COLOR]")
    list_item_aio.setArt({'icon': os.path.join(ICON_DIR, 'aio.png')})
    list_item_aio.setInfo('video', {'plot': 'Pesquisa via AIOStreams (manifest Stremio). Resolve título via Cinemeta (IMDb).'})
    url_aio = build_plugin_url({'action': 'aiostreams_search_dialog'})
    xbmcplugin.addDirectoryItem(HANDLE, url_aio, list_item_aio, isFolder=False)

    # 6. Pesquisar no AllDebrid (cache da conta)
    if ALLDEBRID_APIKEY:
        list_item_ad = xbmcgui.ListItem("[COLOR FFFFD700]Pesquisar no AllDebrid (Cache)[/COLOR]")
        list_item_ad.setArt({'icon': os.path.join(ICON_DIR, 'alldebrid.png')})
        list_item_ad.setInfo('video', {'plot': 'Pesquisar por nome dentro dos magnets prontos e links salvos da sua conta AllDebrid'})
        url_ad = build_plugin_url({'action': 'ad_search_dialog'})
        xbmcplugin.addDirectoryItem(HANDLE, url_ad, list_item_ad, isFolder=False)

    # 7. Pesquisa Global
    list_item5 = xbmcgui.ListItem("Pesquisar Torrents (Global)")
    list_item5.setArt({'icon': os.path.join(ICON_DIR, 'prowlarr.png')})
    list_item5.setInfo('video', {'plot': 'Pesquisar em todos os indexadores configurados'})
    url5 = build_plugin_url({'action': 'search_dialog'})
    xbmcplugin.addDirectoryItem(HANDLE, url5, list_item5, isFolder=False)

    # 8. Meu AllDebrid (cache da conta)
    if ALLDEBRID_APIKEY:
        list_item6 = xbmcgui.ListItem("[COLOR FFFFD700]Meu AllDebrid (Cache)[/COLOR]")
        list_item6.setInfo('video', {'plot': 'Visualizar torrents (magnets) e links salvos na sua conta AllDebrid'})
        url6 = build_plugin_url({'action': 'alldebrid_menu'})
        xbmcplugin.addDirectoryItem(HANDLE, url6, list_item6, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def search_dialog():
    kb = xbmc.Keyboard('', 'Digite o termo de busca')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        if query:
            return query
    return None

# ============================================================================
# PESQUISA EM TRACKERS ESPECÍFICOS (seleção manual)
# ============================================================================

def get_prowlarr_indexers(session):
    if not PROWLARR_APIKEY:
        log("Prowlarr API Key não configurada", xbmc.LOGWARNING)
        return []
    headers = HEADERS.copy()
    headers['X-Api-Key'] = PROWLARR_APIKEY
    try:
        log("[Prowlarr] Buscando lista de indexers...")
        response = session.get(PROWLARR_INDEXER_URL, headers=headers, timeout=30)
        response.raise_for_status()
        indexers = response.json()
        log(f"[Prowlarr] {len(indexers)} indexers encontrados")
        return indexers
    except Exception as e:
        log(f"[Prowlarr] Erro ao buscar indexers: {str(e)}", xbmc.LOGERROR)
        return []

def tracker_search_dialog():
    if not PROWLARR_APIKEY:
        xbmcgui.Dialog().ok("Erro", "API Key do Prowlarr não configurada.\nConfigure em Settings.")
        return
    progress = xbmcgui.DialogProgress()
    progress.create("Prowlarr", "Carregando indexadores...")
    session = create_secure_session()
    indexers = get_prowlarr_indexers(session)
    session.close()
    progress.close()
    if not indexers:
        xbmcgui.Dialog().notification(ADDON_NAME, "Não foi possível carregar os indexers", xbmcgui.NOTIFICATION_ERROR)
        return
    active_indexers = [idx for idx in indexers if idx.get('enable', False)]
    active_indexers.sort(key=lambda x: x.get('name', '').lower())
    if not active_indexers:
        xbmcgui.Dialog().notification(ADDON_NAME, "Nenhum indexer ativo encontrado", xbmcgui.NOTIFICATION_WARNING)
        return
    names = []
    ids = []
    for idx in active_indexers:
        name = idx.get('name', 'Unknown')
        protocol = idx.get('protocol', 'unknown').upper()
        definition = idx.get('definitionName', '')
        display_name = f"{name} [{protocol}]"
        if definition:
            display_name += f" ({definition})"
        names.append(display_name)
        ids.append(str(idx.get('id', 0)))
    dialog = xbmcgui.Dialog()
    # Removido o preselect para que nenhum tracker venha marcado
    selected = dialog.multiselect("Selecione os Trackers para pesquisar", names)
    if not selected:
        log("Seleção de trackers cancelada")
        return
    selected_ids = [ids[i] for i in selected]
    selected_names = [names[i] for i in selected]
    log(f"Trackers selecionados: {selected_names}")
    kb = xbmc.Keyboard('', f'Buscar em {len(selected_ids)} tracker(s)')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        if query:
            url = build_plugin_url({
                'action': 'search',
                'query': query,
                'tracker_ids': ','.join(selected_ids),
                'tracker_names': '|'.join(selected_names)
            })
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            xbmcgui.Dialog().notification(ADDON_NAME, "Busca vazia", xbmcgui.NOTIFICATION_INFO)

# ============================================================================
# FUNÇÕES PARA PESQUISAS PRÉ-CONFIGURADAS (PÚBLICOS, PRIVADOS, NO H&R)
# ============================================================================

def public_search_dialog():
    if not PROWLARR_APIKEY:
        xbmcgui.Dialog().ok("Erro", "API Key do Prowlarr não configurada.\nConfigure em Settings.")
        return
    if not PROWLARR_PUBLIC_TRACKERS:
        xbmcgui.Dialog().ok("Aviso", "Nenhum tracker público configurado.\nConfigure em Settings os IDs dos trackers (separados por vírgula).")
        return
    kb = xbmc.Keyboard('', 'Digite o termo de busca')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        if query:
            url = build_plugin_url({
                'action': 'search',
                'query': query,
                'tracker_ids': PROWLARR_PUBLIC_TRACKERS,
                'tracker_names': 'Públicos'
            })
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            xbmcgui.Dialog().notification(ADDON_NAME, "Busca vazia", xbmcgui.NOTIFICATION_INFO)

def private_search_dialog():
    if not PROWLARR_APIKEY:
        xbmcgui.Dialog().ok("Erro", "API Key do Prowlarr não configurada.\nConfigure em Settings.")
        return
    if not PROWLARR_PRIVATE_TRACKERS:
        xbmcgui.Dialog().ok("Aviso", "Nenhum tracker privado configurado.\nConfigure em Settings os IDs dos trackers (separados por vírgula).")
        return
    kb = xbmc.Keyboard('', 'Digite o termo de busca')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        if query:
            url = build_plugin_url({
                'action': 'search',
                'query': query,
                'tracker_ids': PROWLARR_PRIVATE_TRACKERS,
                'tracker_names': 'Privados'
            })
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            xbmcgui.Dialog().notification(ADDON_NAME, "Busca vazia", xbmcgui.NOTIFICATION_INFO)

def nohr_search_dialog():
    if not PROWLARR_APIKEY:
        xbmcgui.Dialog().ok("Erro", "API Key do Prowlarr não configurada.\nConfigure em Settings.")
        return
    if not PROWLARR_NOHR_TRACKERS:
        xbmcgui.Dialog().ok("Aviso", "Nenhum tracker No H&R configurado.\nConfigure em Settings os IDs dos trackers (separados por vírgula).")
        return
    kb = xbmc.Keyboard('', 'Digite o termo de busca')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        if query:
            url = build_plugin_url({
                'action': 'search',
                'query': query,
                'tracker_ids': PROWLARR_NOHR_TRACKERS,
                'tracker_names': 'No H&R'
            })
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            xbmcgui.Dialog().notification(ADDON_NAME, "Busca vazia", xbmcgui.NOTIFICATION_INFO)

# ============================================================================
# NORMALIZAÇÃO DOS RESULTADOS
# ============================================================================

def normalize_jackett_result(item):
    return {
        'title': item.get('Title', 'Sem título'),
        'size': item.get('Size', 0),
        'seeders': item.get('Seeders', 0),
        'peers': item.get('Peers', 0),
        'tracker': item.get('Tracker', 'Jackett'),
        'magnet': item.get('MagnetUri', ''),
        'link': item.get('Link', ''),
        'source': 'Jackett'
    }

def normalize_prowlarr_result(item):
    """
    CORRIGIDA: Suporte a indexadores customizados Cardigann/YAML.
    Procura campos específicos por nome antes de busca genérica.
    """
    magnet = ''
    link = ''
    
    # Campos comuns para magnet (ordem de prioridade)
    magnet_fields = [
        'magnetUrl', 'magnetUri', 'magnetLink', 'magnet_link', 'magnetlink',
        'magnet', 'MagnetUri', 'magnet_url'
    ]
    
    # Campos comuns para link de download .torrent (ordem de prioridade)
    link_fields = [
        'downloadUrl', 'download_url', 'download', 'link', 'url',
        'torrentUrl', 'torrent_url', 'torrent', 'DownloadURL',
        'details'  # fallback: às vezes o details é o link direto
    ]
    
    # 1. Procura magnet em campos específicos
    for field in magnet_fields:
        val = item.get(field)
        if isinstance(val, str) and val.startswith('magnet:'):
            magnet = val
            log(f"Prowlarr: Magnet encontrado no campo '{field}': {val[:80]}...")
            break
    
    # 2. Procura link de download em campos específicos
    if not magnet:
        for field in link_fields:
            val = item.get(field)
            if isinstance(val, str):
                if val.startswith('magnet:'):
                    magnet = val
                    log(f"Prowlarr: Magnet encontrado no campo '{field}'")
                    break
                elif val.startswith('http://') or val.startswith('https://'):
                    # Evita pegar URLs que claramente NÃO são torrents
                    lower = val.lower()
                    if any(x in lower for x in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '/poster', '/banner', '/cover']):
                        continue
                    link = val
                    log(f"Prowlarr: Link encontrado no campo '{field}': {val[:80]}...")
                    break
    
    # 3. Se ainda não achou, faz busca genérica mas segura nos valores
    if not magnet and not link:
        def find_safe_url(obj, depth=0):
            if depth > 10:
                return None
            if isinstance(obj, dict):
                for key, value in obj.items():
                    key_lower = key.lower()
                    # Pula campos que obviamente não são download
                    if any(x in key_lower for x in ['poster', 'banner', 'image', 'thumb', 'cover', 'imdb', 'tmdb', 'tvdb']):
                        continue
                    if isinstance(value, str):
                        if value.startswith('magnet:'):
                            return ('magnet', value)
                        if value.startswith('http') and not any(x in value.lower() for x in ['.jpg', '.png', '.gif', '.jpeg', 'imdb.com', 'themoviedb.org']):
                            return ('link', value)
                    result = find_safe_url(value, depth+1)
                    if result:
                        return result
            elif isinstance(obj, list):
                for it in obj:
                    result = find_safe_url(it, depth+1)
                    if result:
                        return result
            return None
        
        found = find_safe_url(item)
        if found:
            tipo, valor = found
            if tipo == 'magnet':
                magnet = valor
            else:
                link = valor
            log(f"Prowlarr: URL encontrada via busca genérica ({tipo}): {valor[:80]}...")
    
    # 4. Gera magnet a partir de infoHash se disponível
    if not magnet and not link:
        info_hash = item.get('infoHash') or item.get('infohash') or item.get('hash')
        if info_hash and len(info_hash) == 40:
            title = item.get('title', '')
            magnet = f"magnet:?xt=urn:btih:{info_hash}"
            if title:
                magnet += f"&dn={urllib.parse.quote_plus(title)}"
            log(f"Prowlarr: Magnet gerado do infoHash: {info_hash}")
    
    # 5. Validação final
    if magnet and not magnet.startswith('magnet:'):
        magnet = ''
    
    return {
        'title': item.get('title', 'Sem título'),
        'size': item.get('size', 0) or 0,
        'seeders': item.get('seeders', 0) or 0,
        'peers': item.get('leechers', 0) or item.get('peers', 0) or 0,
        'tracker': item.get('indexer', 'Prowlarr'),
        'magnet': magnet,
        'link': link,
        'source': 'Prowlarr'
    }

# ============================================================================
# BUSCAS
# ============================================================================

def get_jackett_results(query, timeout, session):
    if not JACKETT_APIKEY:
        return None
    params = {'apikey': JACKETT_APIKEY, 'Query': query}
    try:
        log(f"[Jackett] Pesquisando: {query}")
        response = session.get(JACKETT_SEARCH_URL, params=params, headers=HEADERS, timeout=(10, timeout))
        response.raise_for_status()
        data = response.json()
        if 'Results' in data:
            return [normalize_jackett_result(r) for r in data['Results']]
        return []
    except Exception as e:
        log(f"[Jackett] Erro: {str(e)}", xbmc.LOGERROR)
        return None

def get_prowlarr_results(query, timeout, session, indexer_ids=None):
    if not PROWLARR_APIKEY:
        return None
    headers = HEADERS.copy()
    headers['X-Api-Key'] = PROWLARR_APIKEY
    params = [('query', query), ('type', 'search'), ('limit', '100'), ('offset', '0')]
    if indexer_ids:
        if isinstance(indexer_ids, list):
            for iid in indexer_ids:
                params.append(('indexerIds', str(iid)))
        else:
            params.append(('indexerIds', str(indexer_ids)))
        log(f"[Prowlarr] Buscando apenas nos indexers IDs: {indexer_ids}")
    else:
        log(f"[Prowlarr] Pesquisando global: {query}")
    try:
        response = session.get(PROWLARR_SEARCH_URL, params=params, headers=headers, timeout=(10, timeout))
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return [normalize_prowlarr_result(r) for r in data]
        return []
    except Exception as e:
        log(f"[Prowlarr] Erro: {str(e)}", xbmc.LOGERROR)
        return None

def do_search_and_display(query, tracker_ids=None, tracker_names=None):
    progress = xbmcgui.DialogProgress()
    ssl_status = "SSL" if VERIFY_SSL else "SSL-OFF"
    if tracker_names:
        display_names = tracker_names.replace('|', ', ')[:50]
        progress.create(ADDON_NAME, f"Pesquisando [{ssl_status}]: {query}[CR]Trackers: {display_names}...")
    else:
        progress.create(ADDON_NAME, f"Pesquisando [{ssl_status}]: {query}")
    results_container = []
    search_error = [False]
    session = create_secure_session()
    def jackett_thread():
        if SEARCH_SOURCE in [0, 2] and not tracker_ids:
            res = get_jackett_results(query, MAX_SEARCH_TIME, session)
            if res is None:
                with results_lock:
                    search_error[0] = True
            else:
                with results_lock:
                    results_container.extend(res)
    def prowlarr_thread():
        if SEARCH_SOURCE in [1, 2]:
            ids_list = None
            if tracker_ids:
                ids_list = [tid.strip() for tid in tracker_ids.split(',') if tid.strip()]
            res = get_prowlarr_results(query, MAX_SEARCH_TIME, session, indexer_ids=ids_list)
            if res is None:
                with results_lock:
                    search_error[0] = True
            else:
                with results_lock:
                    results_container.extend(res)
    threads = []
    if SEARCH_SOURCE in [0, 2] and not tracker_ids:
        t1 = threading.Thread(target=jackett_thread)
        t1.start()
        threads.append(t1)
    if SEARCH_SOURCE in [1, 2]:
        t2 = threading.Thread(target=prowlarr_thread)
        t2.start()
        threads.append(t2)
    start = time.time()
    while any(t.is_alive() for t in threads) and (time.time() - start) < MAX_SEARCH_TIME + 5:
        if progress.iscanceled():
            log("Pesquisa cancelada pelo usuário.")
            break
        elapsed = time.time() - start
        percent = min(int((elapsed / MAX_SEARCH_TIME) * 100), 100)
        progress.update(percent)
        xbmc.sleep(100)
    progress.close()
    for t in threads:
        if t.is_alive():
            t.join(2)
    session.close()
    if not results_container and search_error[0]:
        xbmcgui.Dialog().notification(ADDON_NAME, "Erro na pesquisa. Verifique configurações.", xbmcgui.NOTIFICATION_ERROR)
        return
    if not results_container:
        xbmcgui.Dialog().notification(ADDON_NAME, "Nenhum resultado encontrado.", xbmcgui.NOTIFICATION_INFO)
        return
    results_container.sort(key=lambda x: x.get('seeders', 0), reverse=True)
    display_results(results_container, selected_trackers=tracker_names)

def display_results(results, selected_trackers=None):
    xbmcplugin.setContent(HANDLE, 'videos')
    sources = {}
    for r in results:
        src = r.get('source', 'Desconhecido')
        sources[src] = sources.get(src, 0) + 1
    log(f"Exibindo {len(results)} resultados totais: {sources}")
    if selected_trackers:
        tracker_list = selected_trackers.replace('|', ', ')
        log(f"Resultados filtrados por trackers: {tracker_list}")
    items = []
    TRACKER_COLORS = {
        'amigos share club': 'FF00008B', 'amigos share': 'FF00008B','Starckfilmes': 'green','starckfilmes': 'green',
        'capybarabr': 'yellow', 'capybara': 'yellow','ThepirataFilmes': 'black','bludv': 'blue','Bludv': 'blue',
        'samaritano': 'orange', 'samaritano (api)': 'orange','thepiratafilmes': 'black','torrent dos filmes': 'blue','starckfilmes': 'orange',
    }
    # Mapeamento tracker -> ícone (matching por substring, case-insensitive).
    # Coloque os PNGs em resources/media/. Adicione/edite à vontade.
    TRACKER_ICONS = {
        'capybarabr': 'capybara.jpg',
        'capybara': 'capybara.jpg',
        'amigos share club': 'amigos.jpg',
        'amigos share': 'amigos.jpg',
        'amigos': 'amigos.jpg',
        'samaritano': 'samaritano.jpg',
        'bludv': 'bludv.png',
        'Comando': 'comando.png',
        'torrent dos filmes': 'torrent dos filmes.png',
        'ThepirataFilmes': 'pirata.png',
        'thepiratafilmes': 'pirata.png',
        'vacatorrent': 'vaca.png',
        'Catálogo BeTor': 'betor.png',
        'catálogo betor': 'betor.png',
        'catalogo betor': 'betor.png',
        'catalogo-betor': 'betor.png',
        'Starckfilmes': 'starck.png',
        'starckfilmes': 'starck.png',
    }
    default_icon = os.path.join(ICON_DIR, 'default.png')
    for item in results:
        title = item['title']
        size = item['size']
        seeders = item['seeders']
        peers = item['peers']
        tracker = item['tracker']
        magnet = item['magnet']
        torrent_url = item['link']
        if not magnet and not torrent_url:
            log(f"Ignorando resultado sem link: {title}")
            continue
        release_info = parse_release_info(title)
        size_str = f"{size / (1024**3):.2f} GB" if size else "N/A"
        tracker_lower = tracker.lower()
        tracker_color = 'gray'
        for tname, color in TRACKER_COLORS.items():
            if tname in tracker_lower:
                tracker_color = color
                break
        details = []
        details.append(f"[COLOR {tracker_color}]{tracker}[/COLOR]")
        details.append(f"[COLOR green]↑{seeders}[/COLOR]")
        if peers > 0:
            details.append(f"[COLOR red]↓{peers}[/COLOR]")
        if release_info['resolution']:
            details.append(f"[COLOR blue]{release_info['resolution']}[/COLOR]")
        if release_info['source']:
            details.append(release_info['source'])
        if release_info['audio']:
            details.append(f"[COLOR yellow]{release_info['audio']}[/COLOR]")
        if release_info['codec']:
            details.append(release_info['codec'])
        details.append(f"[COLOR white]{size_str}[/COLOR]")
        label2 = " | ".join(details)
        clean_title = title[:67] + "..." if len(title) > 70 else title
        full_label = f"{clean_title}\n[COLOR dimgray]{label2}[/COLOR]"
        list_item = xbmcgui.ListItem(label=full_label)
        list_item.setInfo('video', {'title': title, 'size': size, 'plot': label2})
        # Ícone específico por tracker
        icon_file = None
        for tname, fname in TRACKER_ICONS.items():
            if tname in tracker_lower:
                icon_file = fname
                break
        icon_path = os.path.join(ICON_DIR, icon_file) if icon_file else default_icon
        list_item.setArt({'icon': icon_path, 'thumb': icon_path})
        list_item.setProperty('IsPlayable', 'true')
        valid_magnet = magnet if magnet and magnet.startswith('magnet:') else ''
        play_url = build_plugin_url({
            'action': 'play',
            'title': title,
            'magnet': valid_magnet,
            'torrent': torrent_url if not valid_magnet else ''
        })
        items.append((play_url, list_item, False))
    if items:
        xbmcplugin.addDirectoryItems(HANDLE, items)
        log(f"Inseridos {len(items)} itens")
    else:
        log("Nenhum item válido para exibir")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

# ============================================================================
# ALLDEBRID FUNCTIONS (UPLOAD, STATUS, STREAM)
# ============================================================================

def alldebrid_upload_torrent_file(torrent_data, filename, api_key):
    if not torrent_data or not api_key:
        log("AllDebrid: Dados ou API Key ausente", xbmc.LOGERROR)
        return None
    url = f"{ALLDEBRID_API_URL}/magnet/upload/file"
    files = {'files[0]': (filename, io.BytesIO(torrent_data), 'application/x-bittorrent')}
    headers = {'Authorization': f'Bearer {api_key}', 'User-Agent': 'Kodi-AllDebrid-Addon'}
    try:
        log(f"AllDebrid: Upload arquivo .torrent ({len(torrent_data)} bytes)...")
        response = requests.post(url, headers=headers, files=files, timeout=60)
        resp_data = response.json()
        log(f"AllDebrid: Resposta upload - {str(resp_data)[:200]}")
        if resp_data.get('status') == 'success':
            files_data = resp_data.get('data', {}).get('files', [])
            if files_data and len(files_data) > 0:
                torrent_info = files_data[0]
                if 'error' in torrent_info:
                    log(f"AllDebrid: Erro no arquivo - {torrent_info['error']}", xbmc.LOGERROR)
                    return None
                torrent_id = torrent_info.get('id')
                log(f"AllDebrid: Upload OK - ID {torrent_id}")
                return torrent_id
            else:
                log(f"AllDebrid: Resposta sem files - {resp_data}", xbmc.LOGWARNING)
                return None
        else:
            error_msg = resp_data.get('error', {}).get('message', str(resp_data))
            log(f"AllDebrid: Erro upload - {error_msg}", xbmc.LOGERROR)
            return None
    except Exception as e:
        log(f"AllDebrid: Erro upload arquivo - {str(e)}", xbmc.LOGERROR)
        return None

def alldebrid_upload_magnet(magnet_url, api_key):
    if not magnet_url or not api_key:
        log("AllDebrid: Magnet ou API Key ausente", xbmc.LOGERROR)
        return None
    url = f"{ALLDEBRID_API_URL}/magnet/upload"
    headers = {'Authorization': f'Bearer {api_key}', 'User-Agent': 'Kodi-AllDebrid-Addon', 'Content-Type': 'application/x-www-form-urlencoded'}
    data = {'magnets[]': magnet_url}
    try:
        log("AllDebrid: Enviando magnet...")
        response = requests.post(url, headers=headers, data=data, timeout=30)
        resp_data = response.json()
        if resp_data.get('status') == 'success':
            magnet_data = resp_data.get('data', {}).get('magnets', [])
            if magnet_data and len(magnet_data) > 0:
                item_id = magnet_data[0].get('id') or magnet_data[0].get('magnet_id')
                log(f"AllDebrid: Magnet ID {item_id}")
                return item_id
            else:
                log(f"AllDebrid: Resposta sem magnets - {resp_data}", xbmc.LOGWARNING)
                return None
        else:
            error_msg = resp_data.get('error', {}).get('message', str(resp_data))
            log(f"AllDebrid: Erro magnet - {error_msg}", xbmc.LOGERROR)
            return None
    except Exception as e:
        log(f"AllDebrid: Erro magnet - {str(e)}", xbmc.LOGERROR)
        return None

def alldebrid_check_status(item_id, api_key):
    url = f"{ALLDEBRID_API_URL}/magnet/status"
    headers = {'Authorization': f'Bearer {api_key}', 'User-Agent': 'Kodi-AllDebrid-Addon'}
    params = {'id': item_id}
    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        data = response.json()
        log(f"AllDebrid: Status response - {str(data)[:300]}")
        if data.get('status') == 'success':
            magnets_data = data.get('data', {}).get('magnets', {})
            if isinstance(magnets_data, list) and len(magnets_data) > 0:
                return magnets_data[0]
            elif isinstance(magnets_data, dict):
                return magnets_data
            return data.get('data', {})
        else:
            error_msg = data.get('error', {}).get('message', str(data))
            log(f"AllDebrid: Erro status - {error_msg}", xbmc.LOGWARNING)
            return None
    except Exception as e:
        log(f"AllDebrid: Erro check - {str(e)}", xbmc.LOGERROR)
        return None

def alldebrid_get_stream_link(item_id, api_key):
    url = f"{ALLDEBRID_API_URL}/magnet/files"
    headers = {'Authorization': f'Bearer {api_key}', 'User-Agent': 'Kodi-AllDebrid-Addon'}
    params = {'id[]': item_id}
    try:
        log(f"AllDebrid: Obtendo arquivos para ID {item_id}")
        response = requests.get(url, headers=headers, params=params, timeout=30)
        data = response.json()
        if data.get('status') != 'success':
            error_msg = data.get('error', {}).get('message', str(data))
            log(f"AllDebrid: Erro files - {error_msg}", xbmc.LOGERROR)
            return None
        magnets_data = data.get('data', {}).get('magnets', {})
        if isinstance(magnets_data, dict):
            magnet_data = magnets_data.get(str(item_id))
            if not magnet_data and magnets_data:
                magnet_data = list(magnets_data.values())[0]
        elif isinstance(magnets_data, list) and len(magnets_data) > 0:
            magnet_data = magnets_data[0]
        else:
            log("AllDebrid: Estrutura de magnets inválida", xbmc.LOGWARNING)
            return None
        if not magnet_data:
            log("AllDebrid: Sem dados do magnet", xbmc.LOGWARNING)
            return None
        files = magnet_data.get('files', [])
        if not files:
            log("AllDebrid: Sem arquivos", xbmc.LOGWARNING)
            return None
        def extract_files(file_list, path=""):
            result = []
            for f in file_list:
                if not isinstance(f, dict):
                    continue
                if 'e' in f and isinstance(f['e'], list):
                    folder_name = f.get('n', 'unknown')
                    result.extend(extract_files(f['e'], path + folder_name + "/"))
                else:
                    f['full_path'] = path + f.get('n', 'unknown')
                    result.append(f)
            return result
        all_files = extract_files(files)
        log(f"AllDebrid: Total arquivos extraídos: {len(all_files)}")
        video_exts = ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.m4v', '.mpg', '.webm']
        video_files = []
        for f in all_files:
            name = f.get('n', '')
            if any(name.lower().endswith(ext) for ext in video_exts):
                file_link = f.get('l') or f.get('link')
                if file_link:
                    video_files.append({
                        'filename': name,
                        'size': f.get('s', 0),
                        'file_link': file_link,
                        'full_path': f.get('full_path', name)
                    })
        if not video_files:
            log("AllDebrid: Nenhum arquivo de vídeo encontrado!", xbmc.LOGERROR)
            return None
        log(f"AllDebrid: {len(video_files)} arquivos de vídeo disponíveis")
        for vf in video_files:
            log(f"  -> {vf['filename']} ({vf['size']/(1024**3):.2f} GB)")
        return video_files
    except Exception as e:
        log(f"AllDebrid: Erro get link - {str(e)}", xbmc.LOGERROR)
        import traceback
        log(f"AllDebrid: Traceback - {traceback.format_exc()}", xbmc.LOGERROR)
        return None

def alldebrid_get_direct_stream(file_link, api_key):
    if not file_link or not api_key:
        log("AllDebrid: Link ou API ausente", xbmc.LOGERROR)
        return file_link
    file_id = file_link.split('/')[-1]
    log(f"AllDebrid: Convertendo /f/{file_id}...")
    headers = {'Authorization': f'Bearer {api_key}', 'User-Agent': 'Kodi-AllDebrid-Addon'}
    unlock_url = f"{ALLDEBRID_API_URL}/link/unlock?agent=KodiAddon&link={quote_plus(file_link)}"
    try:
        unlock_resp = requests.get(unlock_url, headers=headers, timeout=20).json()
        log(f"AllDebrid Unlock: {unlock_resp}")
        if unlock_resp.get('status') == 'success':
            direct_link = unlock_resp['data'].get('link', file_link)
            if direct_link and direct_link.startswith('http') and 'debrid.it/dl/' in direct_link:
                log(f"AllDebrid: ***LINK DIRETO MKV***: {direct_link}")
                return direct_link
            streams = unlock_resp['data'].get('streams', [])
            if streams:
                best_stream = max(streams, key=lambda x: int(x.get('quality', 0)) if x.get('quality').isdigit() else 0)
                stream_id = best_stream['id']
                stream_url = f"{ALLDEBRID_API_URL}/link/streaming?agent=KodiAddon&id={unlock_resp['data']['id']}&stream={stream_id}"
                stream_resp = requests.get(stream_url, headers=headers, timeout=20).json()
                if stream_resp.get('status') == 'success':
                    return stream_resp['data']['download']
    except Exception as e:
        log(f"Direct stream erro: {e}", xbmc.LOGERROR)
    return file_link

def alldebrid_process_and_play(magnet_url, torrent_url, title, api_key):
    progress = xbmcgui.DialogProgress()
    progress.create("AllDebrid", "Iniciando...")
    item_id = None
    
    # Normaliza entradas
    real_magnet = ''
    real_torrent = ''
    
    if magnet_url and magnet_url.startswith('magnet:'):
        real_magnet = magnet_url
    elif magnet_url and magnet_url.startswith('http'):
        real_torrent = magnet_url
    
    if torrent_url and torrent_url.startswith('http'):
        real_torrent = torrent_url
    
    try:
        if real_magnet:
            progress.update(10, "Enviando magnet...")
            item_id = alldebrid_upload_magnet(real_magnet, api_key)
        
        elif real_torrent:
            progress.update(5, "Baixando .torrent...")
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/x-bittorrent,*/*,application/octet-stream'
            }
            # IMPORTANTE: adiciona API key do Prowlarr se o link for do Prowlarr
            if PROWLARR_APIKEY and ('prowlarr.' in real_torrent or '/download?' in real_torrent):
                headers['X-Api-Key'] = PROWLARR_APIKEY
                log("AllDebrid: Usando X-Api-Key do Prowlarr no download")
            
            session = create_secure_session()
            resp = session.get(real_torrent, headers=headers, timeout=30, allow_redirects=True)
            resp.raise_for_status()
            torrent_data = resp.content
            session.close()
            
            log(f"AllDebrid: Torrent baixado: {len(torrent_data)} bytes")
            
            # Tenta upload do arquivo .torrent direto
            progress.update(15, "Enviando para AllDebrid...")
            item_id = alldebrid_upload_torrent_file(torrent_data, "download.torrent", api_key)
            
            # Se falhou, extrai magnet do .torrent e tenta
            if not item_id and len(torrent_data) > 100:
                log("AllDebrid: Fallback - extraindo magnet do .torrent...")
                try:
                    torrent_dict = bdecode(torrent_data)
                    info = torrent_dict[b'info']
                    info_hash = hashlib.sha1(bencode_encode(info)).hexdigest()
                    name = ''
                    if b'name' in info:
                        raw = info[b'name']
                        name = raw.decode('utf-8', errors='ignore') if isinstance(raw, bytes) else str(raw)
                    fallback_magnet = f"magnet:?xt=urn:btih:{info_hash}"
                    if name:
                        fallback_magnet += f"&dn={urllib.parse.quote_plus(name)}"
                    # Adiciona trackers do .torrent
                    if b'announce' in torrent_dict:
                        ann = torrent_dict[b'announce']
                        if isinstance(ann, bytes):
                            fallback_magnet += f"&tr={urllib.parse.quote_plus(ann.decode('utf-8', errors='ignore'))}"
                    if b'announce-list' in torrent_dict:
                        for tier in torrent_dict[b'announce-list']:
                            if isinstance(tier, list):
                                for tr in tier:
                                    if isinstance(tr, bytes):
                                        fallback_magnet += f"&tr={urllib.parse.quote_plus(tr.decode('utf-8', errors='ignore'))}"
                            elif isinstance(tier, bytes):
                                fallback_magnet += f"&tr={urllib.parse.quote_plus(tier.decode('utf-8', errors='ignore'))}"
                    
                    item_id = alldebrid_upload_magnet(fallback_magnet, api_key)
                except Exception as e:
                    log(f"Fallback erro: {e}", xbmc.LOGERROR)
        else:
            raise ValueError("Sem link válido")
        
        if not item_id:
            raise Exception("Falha no upload para o AllDebrid")
        
        # ... resto do código de status/files/stream permanece igual ...
        log(f"AllDebrid: ID {item_id} - aguardando...")
        max_wait = 180
        waited = 0
        last_status = ""
        while waited < max_wait:
            if progress.iscanceled():
                progress.close()
                return
            percent = min(int((waited / max_wait) * 100), 99)
            progress.update(percent, f"Status: {last_status}[CR]{waited}s")
            status = alldebrid_check_status(item_id, api_key)
            if not status:
                raise Exception("Erro ao verificar status")
            current = str(status.get('status', '')).lower()
            if current != last_status:
                last_status = current
                log(f"Novo status: {current}")
            if current in ['4', 'ready', 'downloaded', 'done']:
                log("AllDebrid: READY!")
                break
            xbmc.sleep(3000)
            waited += 3
        
        progress.update(100, "Obtendo lista de arquivos...")
        video_files = alldebrid_get_stream_link(item_id, api_key)
        if not video_files:
            raise Exception("Nenhum arquivo de vídeo encontrado")
        
        display_items = []
        file_list = []
        for vf in video_files:
            info = extract_video_info(vf['filename'])
            size_gb = vf['size'] / (1024**3)
            parts = []
            if info['episode']:
                parts.append(f"[B]{info['episode']}[/B]")
            else:
                short_name = vf['filename'][:40]
                parts.append(short_name)
            if info['quality']:
                parts.append(f"[COLOR blue]{info['quality']}[/COLOR]")
            if info['source']:
                parts.append(info['source'])
            if info['audio']:
                parts.append(f"[COLOR yellow]{info['audio']}[/COLOR]")
            if info['codec']:
                parts.append(info['codec'])
            parts.append(f"[COLOR white]{size_gb:.2f} GB[/COLOR]")
            label = " | ".join(parts)
            display_items.append(label)
            file_list.append(vf)
        
        if len(display_items) == 1:
            selected_idx = 0
        else:
            dialog = xbmcgui.Dialog()
            selected_idx = dialog.select("Selecione o episódio", display_items)
            if selected_idx < 0:
                progress.close()
                xbmcgui.Dialog().notification(ADDON_NAME, "Seleção cancelada", xbmcgui.NOTIFICATION_WARNING)
                return
        
        selected_file = file_list[selected_idx]
        log(f"AllDebrid: Arquivo selecionado: {selected_file['filename']}")
        
        progress.update(95, "Desbloqueando link...")
        direct_url = alldebrid_get_direct_stream(selected_file['file_link'], api_key)
        if not direct_url or direct_url == selected_file['file_link']:
            direct_url = selected_file['file_link']
        
        stream_url = direct_url
        filename = selected_file['filename']
        file_size = selected_file['size']
        log(f"[AllDebrid][PLAY] Stream URL: {stream_url[:100]}...")
        progress.close()
        
        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setInfo('video', {
            'title': title or filename,
            'plot': f"AllDebrid • {file_size/(1024**3):.2f} GB",
            'mediatype': 'video'
        })
        list_item.setProperty('IsPlayable', 'true')
        list_item.setContentLookup(False)
        if stream_url.lower().endswith('.mkv'):
            list_item.setMimeType('video/x-matroska')
        elif stream_url.lower().endswith('.mp4'):
            list_item.setMimeType('video/mp4')
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        log("[AllDebrid][PLAY] setResolvedUrl OK")
        return
        
    except Exception as e:
        progress.close()
        log(f"ERRO AllDebrid: {str(e)}", xbmc.LOGERROR)
        import traceback
        log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("AllDebrid", f"Erro: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 8000)

# ============================================================================
# ALLDEBRID CACHE / CLOUD (Magnets, Links salvos, Status da conta)
# ============================================================================

def _ad_headers(api_key):
    return {
        'Authorization': f'Bearer {api_key}',
        'User-Agent': 'Kodi-AllDebrid-Addon'
    }

def alldebrid_get_user_info(api_key):
    if not api_key:
        return None
    url = f"{ALLDEBRID_API_URL}/user?agent=KodiAddon"
    try:
        session = create_secure_session()
        resp = session.get(url, headers=_ad_headers(api_key), timeout=15, verify=VERIFY_SSL)
        data = resp.json()
        if data.get('status') == 'success':
            return data.get('data', {}).get('user', {})
        log(f"AllDebrid user: erro - {data}", xbmc.LOGWARNING)
    except Exception as e:
        log(f"AllDebrid user: exceção - {str(e)}", xbmc.LOGERROR)
    return None

def alldebrid_list_magnets(api_key):
    if not api_key:
        return []
    url = f"{ALLDEBRID_API_URL}/magnet/status?agent=KodiAddon"
    try:
        session = create_secure_session()
        resp = session.get(url, headers=_ad_headers(api_key), timeout=30, verify=VERIFY_SSL)
        data = resp.json()
        if data.get('status') != 'success':
            log(f"AllDebrid magnets list: erro - {data}", xbmc.LOGERROR)
            return []
        magnets = data.get('data', {}).get('magnets', [])
        if isinstance(magnets, dict):
            magnets = list(magnets.values())
        return magnets
    except Exception as e:
        log(f"AllDebrid magnets list: exceção - {str(e)}", xbmc.LOGERROR)
        return []

def alldebrid_list_saved_links(api_key):
    if not api_key:
        return []
    url = f"{ALLDEBRID_API_URL}/user/links?agent=KodiAddon"
    try:
        session = create_secure_session()
        resp = session.get(url, headers=_ad_headers(api_key), timeout=20, verify=VERIFY_SSL)
        data = resp.json()
        if data.get('status') != 'success':
            log(f"AllDebrid saved links: erro - {data}", xbmc.LOGWARNING)
            return []
        return data.get('data', {}).get('links', []) or []
    except Exception as e:
        log(f"AllDebrid saved links: exceção - {str(e)}", xbmc.LOGERROR)
        return []

def alldebrid_unlock_link(link, api_key):
    if not link or not api_key:
        return None
    url = f"{ALLDEBRID_API_URL}/link/unlock?agent=KodiAddon&link={quote_plus(link)}"
    try:
        session = create_secure_session()
        resp = session.get(url, headers=_ad_headers(api_key), timeout=30, verify=VERIFY_SSL)
        data = resp.json()
        if data.get('status') == 'success':
            return data.get('data', {}).get('link')
        log(f"AllDebrid unlock: erro - {data}", xbmc.LOGWARNING)
    except Exception as e:
        log(f"AllDebrid unlock: exceção - {str(e)}", xbmc.LOGERROR)
    return None

def show_alldebrid_menu():
    if not ALLDEBRID_APIKEY:
        xbmcgui.Dialog().ok("AllDebrid", "Configure sua API Key do AllDebrid nas opções do addon.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    items = [
        ("[COLOR FF66D9EF]Meus Torrents (Magnets)[/COLOR]",
         {'action': 'ad_list_magnets'}, True,
         "Lista todos os torrents enviados para sua conta AllDebrid"),
        ("[COLOR FF66D9EF]Meus Links Salvos (Hosters)[/COLOR]",
         {'action': 'ad_list_links'}, True,
         "Lista links de hosters salvos (1fichier, Rapidgator, Mega, ...)"),
        ("[COLOR FFFFD700]Status da Conta[/COLOR]",
         {'action': 'ad_account_status'}, False,
         "Ver e-mail, status premium e dias restantes"),
    ]
    for label, params, is_folder, plot in items:
        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url(params), li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def show_account_status():
    info = alldebrid_get_user_info(ALLDEBRID_APIKEY)
    if not info:
        xbmcgui.Dialog().ok("AllDebrid", "Não foi possível obter informações da conta.\nVerifique sua API Key.")
        return
    is_premium = info.get('isPremium', False)
    premium_until = info.get('premiumUntil', 0)
    days_left = 0
    if premium_until:
        days_left = max(0, int((premium_until - time.time()) / 86400))
    msg_lines = [
        f"Usuário: {info.get('username', '-')}",
        f"E-mail: {info.get('email', '-')}",
        f"Premium: {'SIM' if is_premium else 'NÃO'}",
        f"Dias restantes: {days_left}",
        f"Tráfego usado (24h): {info.get('fidelityPoints', 0)} pontos fidelidade",
    ]
    xbmcgui.Dialog().textviewer("Status AllDebrid", "\n".join(msg_lines))

def _format_size(num_bytes):
    try:
        num_bytes = float(num_bytes or 0)
    except Exception:
        return ""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if num_bytes < 1024:
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.2f} PB"

def list_alldebrid_magnets():
    progress = xbmcgui.DialogProgress()
    progress.create("AllDebrid", "Carregando seus torrents...")
    magnets = alldebrid_list_magnets(ALLDEBRID_APIKEY)
    progress.close()

    if not magnets:
        xbmcgui.Dialog().notification("AllDebrid", "Nenhum torrent encontrado na conta",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    def sort_key(m):
        ready = 1 if (m.get('statusCode') == 4 or m.get('status') == 'Ready') else 0
        return (-ready, -(m.get('uploadDate') or 0))
    magnets.sort(key=sort_key)

    for m in magnets:
        item_id = m.get('id')
        filename = m.get('filename') or m.get('name') or f"Magnet {item_id}"
        status = m.get('status', '')
        status_code = m.get('statusCode', -1)
        size = _format_size(m.get('size'))
        is_ready = (status_code == 4) or (status == 'Ready')

        if is_ready:
            label = f"[COLOR FF00FF00]●[/COLOR] {filename}  [COLOR FF888888]({size})[/COLOR]"
            is_folder = True
            params = {'action': 'ad_magnet_files', 'magnet_id': str(item_id), 'title': filename}
        else:
            progress_pct = m.get('downloaded', 0)
            try:
                total = float(m.get('size') or 0)
                pct = (float(progress_pct) / total * 100) if total else 0
            except Exception:
                pct = 0
            label = f"[COLOR FFFFAA00]●[/COLOR] {filename}  [COLOR FF888888]({status} {pct:.0f}%)[/COLOR]"
            is_folder = False
            params = {'action': 'ad_magnet_not_ready'}

        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'plot': f"Status: {status}\nTamanho: {size}\nID: {item_id}"})
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url(params), li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def list_magnet_files(magnet_id, title):
    if not magnet_id:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    progress = xbmcgui.DialogProgress()
    progress.create("AllDebrid", "Listando arquivos...")
    video_files = alldebrid_get_stream_link(magnet_id, ALLDEBRID_APIKEY)
    progress.close()

    if not video_files:
        xbmcgui.Dialog().notification("AllDebrid", "Nenhum arquivo de vídeo encontrado",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    video_files.sort(key=lambda f: f.get('size', 0), reverse=True)

    for f in video_files:
        fname = f.get('filename', 'arquivo')
        fsize = _format_size(f.get('size'))
        flink = f.get('file_link', '')
        label = f"{fname}  [COLOR FF888888]({fsize})[/COLOR]"
        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'title': fname, 'plot': f"Tamanho: {fsize}", 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        params = {
            'action': 'ad_play_link',
            'link': flink,
            'title': fname,
        }
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url(params), li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def list_saved_links():
    progress = xbmcgui.DialogProgress()
    progress.create("AllDebrid", "Carregando links salvos...")
    links = alldebrid_list_saved_links(ALLDEBRID_APIKEY)
    progress.close()

    if not links:
        xbmcgui.Dialog().notification("AllDebrid", "Nenhum link salvo na conta",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    for l in links:
        link_url = l.get('link', '')
        filename = l.get('filename') or link_url
        host = l.get('host', '')
        size = _format_size(l.get('size'))
        label = f"{filename}  [COLOR FF888888][{host} • {size}][/COLOR]"
        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'title': filename, 'plot': f"Host: {host}\nTamanho: {size}", 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        params = {
            'action': 'ad_play_link',
            'link': link_url,
            'title': filename,
        }
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url(params), li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def play_alldebrid_link(link, title):
    if not link:
        xbmcgui.Dialog().notification("AllDebrid", "Link inválido", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    progress = xbmcgui.DialogProgress()
    progress.create("AllDebrid", "Resolvendo stream...")
    progress.update(20)

    direct_url = None
    if '/f/' in link:
        direct_url = alldebrid_get_direct_stream(link, ALLDEBRID_APIKEY)
    else:
        direct_url = alldebrid_unlock_link(link, ALLDEBRID_APIKEY)

    progress.close()

    if not direct_url:
        xbmcgui.Dialog().notification("AllDebrid", "Falha ao obter stream",
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    log(f"AllDebrid Cache: stream resolvido => {direct_url}")
    list_item = xbmcgui.ListItem(path=direct_url)
    list_item.setInfo('video', {'title': title or 'AllDebrid', 'mediatype': 'video'})
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

def alldebrid_search_dialog():
    if not ALLDEBRID_APIKEY:
        xbmcgui.Dialog().ok("AllDebrid", "Configure sua API Key do AllDebrid nas opções do addon.")
        return
    kb = xbmc.Keyboard('', 'Pesquisar no AllDebrid (cache)')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    url = build_plugin_url({'action': 'ad_search', 'query': query})
    xbmc.executebuiltin(f'Container.Update({url})')

def alldebrid_search_results(query):
    if not query:
        show_main_menu()
        return

    q = query.lower().strip()
    tokens = [t for t in q.split() if t]

    def match(text):
        if not text:
            return False
        t = text.lower()
        return all(tok in t for tok in tokens)

    progress = xbmcgui.DialogProgress()
    progress.create("AllDebrid", f"Pesquisando '{query}' no cache...")
    progress.update(20, "Carregando magnets...")
    magnets = alldebrid_list_magnets(ALLDEBRID_APIKEY) or []
    progress.update(60, "Carregando links salvos...")
    saved_links = alldebrid_list_saved_links(ALLDEBRID_APIKEY) or []
    progress.update(90, "Filtrando resultados...")

    matched_magnets = []
    for m in magnets:
        name = m.get('filename') or m.get('name') or ''
        status_code = m.get('statusCode', -1)
        status = m.get('status', '')
        is_ready = (status_code == 4) or (status == 'Ready')
        if not is_ready:
            continue
        if match(name):
            matched_magnets.append(m)

    matched_links = [l for l in saved_links
                     if match(l.get('filename') or '') or match(l.get('link') or '')]

    progress.close()

    total = len(matched_magnets) + len(matched_links)
    if total == 0:
        xbmcgui.Dialog().notification("AllDebrid",
                                      f"Nenhum resultado para '{query}'",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    header = xbmcgui.ListItem(
        f"[COLOR FFFFD700]>> {total} resultado(s) para '{query}' (clique para nova busca)[/COLOR]"
    )
    header.setInfo('video', {'plot': f"{len(matched_magnets)} magnets + {len(matched_links)} links salvos"})
    xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url({'action': 'ad_search_dialog'}),
                                header, isFolder=False)

    for m in matched_magnets:
        item_id = m.get('id')
        filename = m.get('filename') or m.get('name') or f"Magnet {item_id}"
        size = _format_size(m.get('size'))
        label = f"[COLOR FF00FF00]●[/COLOR] {filename}  [COLOR FF888888]({size})[/COLOR]"
        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'plot': f"Magnet pronto no AllDebrid\nTamanho: {size}\nID: {item_id}",
                             'mediatype': 'video'})
        params = {'action': 'ad_magnet_files', 'magnet_id': str(item_id), 'title': filename}
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url(params), li, isFolder=True)

    for l in matched_links:
        link_url = l.get('link', '')
        filename = l.get('filename') or link_url
        host = l.get('host', '')
        size = _format_size(l.get('size'))
        label = f"[COLOR FF66D9EF]♦[/COLOR] {filename}  [COLOR FF888888][{host} • {size}][/COLOR]"
        li = xbmcgui.ListItem(label)
        li.setInfo('video', {'title': filename, 'plot': f"Host: {host}\nTamanho: {size}",
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        params = {'action': 'ad_play_link', 'link': link_url, 'title': filename}
        xbmcplugin.addDirectoryItem(HANDLE, build_plugin_url(params), li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

# ============================================================================
# PLAY TORRENT (compatível com Elementum e AllDebrid)
# ============================================================================

def play_torrent(title, magnet, torrent_url):
    valid_magnet = magnet if magnet and magnet.startswith('magnet:') else ''
    valid_torrent = ''
    
    # Normaliza torrent_url
    if torrent_url and (torrent_url.startswith('http://') or torrent_url.startswith('https://')):
        valid_torrent = torrent_url
    
    # Se magnet é na verdade uma URL HTTP (prowlarr às vezes inverte), corrige
    if magnet and (magnet.startswith('http://') or magnet.startswith('https://')):
        if not valid_torrent:
            valid_torrent = magnet
        valid_magnet = ''
    
    mode_name = 'AllDebrid' if PLAYER_MODE == 1 else 'Elementum'
    log(f"[PLAY] Modo={mode_name} | magnet={'<sim>' if valid_magnet else '<nao>'} | torrent={'<sim>' if valid_torrent else '<nao>'}")
    
    if PLAYER_MODE == 1:
        if not ALLDEBRID_APIKEY:
            xbmcgui.Dialog().ok("AllDebrid", "API Key do AllDebrid não configurada nas Settings.")
            return
        alldebrid_process_and_play(valid_magnet, valid_torrent, title, ALLDEBRID_APIKEY)
    else:
        # Elementum precisa de magnet real. Se só tem URL de torrent, converte.
        uri = valid_magnet
        if not uri and valid_torrent:
            log("[PLAY] Elementum: convertendo torrent URL para magnet...")
            uri = download_torrent_and_get_magnet(valid_torrent)
        
        if not uri:
            xbmcgui.Dialog().ok("Erro", "Nenhum link válido para reprodução no Elementum.\nEste tracker pode não fornecer magnet direto.")
            return
        
        elementum_url = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote_plus(uri)}&name={urllib.parse.quote_plus(title)}"
        list_item = xbmcgui.ListItem(path=elementum_url)
        list_item.setInfo('video', {'title': title, 'mediatype': 'video'})
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        log(f"[PLAY] -> Elementum: {elementum_url[:120]}...")

# ============================================================================
# AIOSTREAMS (Stremio addon protocol) - busca via Cinemeta -> /stream/...
# ============================================================================

def _aiostreams_stream_base():
    url = (AIOSTREAMS_URL or '').strip()
    if not url:
        return None
    url = url.split('?', 1)[0].split('#', 1)[0].rstrip('/')
    if url.lower().endswith('/manifest.json'):
        base = url[: -len('/manifest.json')]
        return base.rstrip('/') + '/stream'
    if url.lower().endswith('/stream'):
        return url
    return url + '/stream'

def cinemeta_search(query, content_type):
    try:
        q = quote_plus(query)
        url = f"{CINEMETA_BASE_URL}/catalog/{content_type}/top/search={q}.json"
        log(f"[Cinemeta] GET {url}")
        r = requests.get(url, headers=HEADERS, timeout=20, verify=VERIFY_SSL)
        r.raise_for_status()
        data = r.json() or {}
        return data.get('metas', []) or []
    except Exception as e:
        log(f"[Cinemeta] Erro: {e}", xbmc.LOGERROR)
        return []

def cinemeta_get_series_meta(imdb_id):
    try:
        url = f"{CINEMETA_BASE_URL}/meta/series/{imdb_id}.json"
        r = requests.get(url, headers=HEADERS, timeout=20, verify=VERIFY_SSL)
        r.raise_for_status()
        return (r.json() or {}).get('meta', {}) or {}
    except Exception as e:
        log(f"[Cinemeta] Erro meta série: {e}", xbmc.LOGERROR)
        return {}

def aiostreams_fetch(content_type, stream_id):
    base = _aiostreams_stream_base()
    if not base:
        xbmcgui.Dialog().ok("AIOStreams", "Configure a URL do manifest.json do AIOStreams nas configurações do addon.")
        return []
    url = f"{base}/{content_type}/{stream_id}.json"
    try:
        log(f"[AIOStreams] GET {url}")
        r = requests.get(url, headers=HEADERS, timeout=45, verify=VERIFY_SSL)
        r.raise_for_status()
        data = r.json() or {}
        return data.get('streams', []) or []
    except Exception as e:
        log(f"[AIOStreams] Erro: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("AIOStreams", f"Falha: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)
        return []

def _stream_to_playable(stream):
    title = stream.get('title') or stream.get('name') or 'AIOStreams'
    url = stream.get('url')
    if url and (url.startswith('http://') or url.startswith('https://')):
        return ('http', url, title)
    if url and url.startswith('magnet:'):
        return ('magnet', url, title)
    info_hash = stream.get('infoHash') or stream.get('infohash')
    if info_hash:
        trackers = stream.get('sources') or []
        tr_params = ''
        for s in trackers:
            if isinstance(s, str) and s.startswith('tracker:'):
                tr_params += '&tr=' + quote_plus(s[len('tracker:'):])
        name_q = quote_plus(stream.get('title') or stream.get('name') or info_hash)
        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={name_q}{tr_params}"
        return ('magnet', magnet, title)
    return (None, None, title)

def aiostreams_display_streams(streams, display_title):
    xbmcplugin.setContent(HANDLE, 'videos')
    items = []
    for s in streams:
        kind, uri, st_title = _stream_to_playable(s)
        if not kind or not uri:
            continue
        name = s.get('name') or 'AIOStreams'
        st_full_title = s.get('title') or s.get('description') or st_title or display_title
        first_line = (st_full_title.splitlines()[0] if st_full_title else display_title)
        tag_color = 'FF00BFFF' if kind == 'http' else 'FFFFA500'
        tag = '[HTTP]' if kind == 'http' else '[P2P]'
        label = f"[COLOR {tag_color}]{tag}[/COLOR] [COLOR white]{name}[/COLOR] | {first_line}"
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': first_line, 'plot': st_full_title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        if kind == 'http':
            play_url = build_plugin_url({
                'action': 'aiostreams_play_http',
                'title': first_line,
                'url': uri
            })
        else:
            play_url = build_plugin_url({
                'action': 'play',
                'title': first_line,
                'magnet': uri,
                'torrent': ''
            })
        items.append((play_url, li, False))
    if items:
        xbmcplugin.addDirectoryItems(HANDLE, items)
    else:
        xbmcgui.Dialog().notification("AIOStreams", "Nenhum stream encontrado", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def aiostreams_play_http(title, url):
    log(f"[AIOStreams][PLAY-HTTP] title={title!r}")
    log(f"[AIOStreams][PLAY-HTTP] url={url}")
    if not url:
        xbmcgui.Dialog().notification("AIOStreams", "URL vazia", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Extensões de vídeo direto
    direct_extensions = ('.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.ts')
    # Extensões HLS/m3u8
    hls_extensions = ('.m3u8', '.m3u', '.txt')  # alguns sites usam .txt para m3u8

    url_lower = url.lower()
    
    # Caso 1: URL direta de vídeo
    if url_lower.endswith(direct_extensions):
        li = xbmcgui.ListItem(path=url)
        li.setInfo('video', {'title': title or 'AIOStreams', 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp4' if url_lower.endswith('.mp4') else 'video/x-matroska')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        log("[AIOStreams] URL direta -> reproduzindo")
        return

    # Caso 2: Stream HLS (m3u8)
    if any(url_lower.endswith(ext) for ext in hls_extensions) or '/master.txt' in url_lower or '.m3u8' in url_lower:
        # Para HLS, precisamos garantir que o Kodi use o InputStream Adaptive
        li = xbmcgui.ListItem(path=url)
        li.setInfo('video', {'title': title or 'AIOStreams', 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        # Adiciona cabeçalhos User-Agent para evitar bloqueio
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        log("[AIOStreams] Stream HLS -> reproduzindo com inputstream.adaptive")
        return

    # Caso 3: Tentar extrair magnet da URL (alguns proxies passam magnet na query)
    import urllib.parse as urlparse
    parsed = urlparse.urlparse(url)
    query_params = urlparse.parse_qs(parsed.query)
    magnet = None
    if 'magnet' in query_params:
        magnet = query_params['magnet'][0]
        while '%' in magnet and magnet != urlparse.unquote(magnet):
            magnet = urlparse.unquote(magnet)
        if magnet.startswith('magnet:'):
            log(f"[AIOStreams] Magnet extraído: {magnet[:100]}...")
            play_torrent(title, magnet, '')
            return

    # Caso 4: Tentar seguir redirecionamentos e obter o conteúdo real
    try:
        session = create_secure_session()
        # Faz uma requisição HEAD para ver o Content-Type e URL final
        head_resp = session.head(url, allow_redirects=True, timeout=15, headers={'User-Agent': 'Mozilla/5.0'})
        final_url = head_resp.url
        content_type = head_resp.headers.get('Content-Type', '')
        log(f"[AIOStreams] HEAD -> final_url={final_url}, Content-Type={content_type}")
        
        if final_url.lower().endswith(direct_extensions):
            li = xbmcgui.ListItem(path=final_url)
            li.setInfo('video', {'title': title, 'mediatype': 'video'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
            return
        elif 'mpegurl' in content_type or final_url.lower().endswith('.m3u8'):
            # É HLS
            li = xbmcgui.ListItem(path=final_url)
            li.setInfo('video', {'title': title, 'mediatype': 'video'})
            li.setProperty('IsPlayable', 'true')
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
            return
    except Exception as e:
        log(f"[AIOStreams] Erro no HEAD: {e}", xbmc.LOGWARNING)

    # Caso 5: Se nada funcionou, tenta reproduzir diretamente (pode funcionar com inputstream adaptive genérico)
    li = xbmcgui.ListItem(path=url)
    li.setInfo('video', {'title': title or 'AIOStreams', 'mediatype': 'video'})
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('video/mp4')  # fallback
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    log("[AIOStreams] Tentativa genérica de reprodução")

def aiostreams_search_dialog():
    if not _aiostreams_stream_base():
        xbmcgui.Dialog().ok("AIOStreams", "Configure a URL do manifest.json do AIOStreams nas configurações do addon (campo 'AIOStreams - URL do manifest').")
        show_main_menu()
        return
    choice = xbmcgui.Dialog().select("AIOStreams - Tipo de conteúdo", ["Filme", "Série"])
    if choice < 0:
        show_main_menu()
        return
    content_type = 'movie' if choice == 0 else 'series'
    kb = xbmc.Keyboard('', 'AIOStreams - Digite o nome')
    kb.doModal()
    if not kb.isConfirmed():
        show_main_menu()
        return
    query = kb.getText().strip()
    if not query:
        show_main_menu()
        return
    metas = cinemeta_search(query, content_type)
    if not metas:
        xbmcgui.Dialog().notification("AIOStreams", "Nada encontrado no Cinemeta", xbmcgui.NOTIFICATION_INFO, 3000)
        show_main_menu()
        return
    labels = []
    for m in metas[:30]:
        nm = m.get('name', '?')
        yr = m.get('year') or m.get('releaseInfo') or ''
        labels.append(f"{nm} ({yr})" if yr else nm)
    pick = xbmcgui.Dialog().select(f"AIOStreams - Selecionar {('filme' if content_type=='movie' else 'série')}", labels)
    if pick < 0:
        show_main_menu()
        return
    chosen = metas[pick]
    imdb_id = chosen.get('imdb_id') or chosen.get('id')
    if not imdb_id or not imdb_id.startswith('tt'):
        xbmcgui.Dialog().ok("AIOStreams", "IMDb ID não disponível para este título.")
        show_main_menu()
        return
    title_disp = chosen.get('name', imdb_id)
    if content_type == 'movie':
        url = build_plugin_url({
            'action': 'aiostreams_results',
            'ctype': 'movie',
            'sid': imdb_id,
            'dtitle': title_disp
        })
        xbmc.executebuiltin(f'Container.Update({url})')
        return
    meta = cinemeta_get_series_meta(imdb_id)
    videos = meta.get('videos') or []
    seasons = sorted({v.get('season') for v in videos if v.get('season') and v.get('season') > 0})
    if not seasons:
        xbmcgui.Dialog().ok("AIOStreams", "Sem temporadas disponíveis no Cinemeta.")
        show_main_menu()
        return
    s_pick = xbmcgui.Dialog().select("Temporada", [f"Temporada {s}" for s in seasons])
    if s_pick < 0:
        show_main_menu()
        return
    season_num = seasons[s_pick]
    eps = [v for v in videos if v.get('season') == season_num]
    eps.sort(key=lambda v: v.get('episode') or 0)
    ep_labels = [f"E{v.get('episode'):02d} - {v.get('name','')}" for v in eps if v.get('episode')]
    e_pick = xbmcgui.Dialog().select(f"T{season_num} - Episódio", ep_labels)
    if e_pick < 0:
        show_main_menu()
        return
    ep_num = eps[e_pick].get('episode')
    sid = f"{imdb_id}:{season_num}:{ep_num}"
    dtitle = f"{title_disp} S{season_num:02d}E{ep_num:02d}"
    url = build_plugin_url({
        'action': 'aiostreams_results',
        'ctype': 'series',
        'sid': sid,
        'dtitle': dtitle
    })
    xbmc.executebuiltin(f'Container.Update({url})')

# ============================================================================
# MAIN (COM TODAS AS ACTIONS)
# ============================================================================

def main():
    args = sys.argv[2]
    params = urllib.parse.parse_qs(args[1:]) if args else {}
    action = params.get('action', [None])[0]

    if action == 'play':
        title = params.get('title', [''])[0]
        magnet = params.get('magnet', [''])[0]
        torrent = params.get('torrent', [''])[0]
        play_torrent(title, magnet, torrent)

    elif action == 'search_dialog':
        query = search_dialog()
        if query:
            url = build_plugin_url({'action': 'search', 'query': query})
            xbmc.executebuiltin(f'Container.Update({url})')
        else:
            xbmc.executebuiltin('Container.Refresh')

    elif action == 'tracker_search_dialog':
        tracker_search_dialog()
    elif action == 'public_search_dialog':
        public_search_dialog()
    elif action == 'private_search_dialog':
        private_search_dialog()
    elif action == 'nohr_search_dialog':
        nohr_search_dialog()

    elif action == 'aiostreams_search_dialog':
        aiostreams_search_dialog()
    elif action == 'aiostreams_results':
        ctype = params.get('ctype', ['movie'])[0]
        sid = params.get('sid', [''])[0]
        dtitle = params.get('dtitle', [''])[0]
        if not sid:
            show_main_menu()
        else:
            streams = aiostreams_fetch(ctype, sid)
            aiostreams_display_streams(streams, dtitle)
    elif action == 'aiostreams_play_http':
        aiostreams_play_http(params.get('title', [''])[0], params.get('url', [''])[0])

    elif action == 'search':
        query = params.get('query', [''])[0]
        tracker_ids = params.get('tracker_ids', [''])[0]
        tracker_names = params.get('tracker_names', [''])[0]
        if query:
            do_search_and_display(
                query,
                tracker_ids=tracker_ids if tracker_ids else None,
                tracker_names=tracker_names if tracker_names else None
            )
        else:
            show_main_menu()

    # AllDebrid cache / cloud actions
    elif action == 'ad_search_dialog':
        alldebrid_search_dialog()
    elif action == 'ad_search':
        query = params.get('query', [''])[0]
        alldebrid_search_results(query)
    elif action == 'alldebrid_menu':
        show_alldebrid_menu()
    elif action == 'ad_account_status':
        show_account_status()
        show_main_menu()
    elif action == 'ad_list_magnets':
        list_alldebrid_magnets()
    elif action == 'ad_list_links':
        list_saved_links()
    elif action == 'ad_magnet_files':
        magnet_id = params.get('magnet_id', [''])[0]
        title = params.get('title', [''])[0]
        list_magnet_files(magnet_id, title)
    elif action == 'ad_play_link':
        link = params.get('link', [''])[0]
        title = params.get('title', [''])[0]
        play_alldebrid_link(link, title)
    elif action == 'ad_magnet_not_ready':
        xbmcgui.Dialog().notification("AllDebrid", "Torrent ainda não está pronto",
                                      xbmcgui.NOTIFICATION_INFO, 3000)

    else:
        show_main_menu()

if __name__ == '__main__':
    main()
